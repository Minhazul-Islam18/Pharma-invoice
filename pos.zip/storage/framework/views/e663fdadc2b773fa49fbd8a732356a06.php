<footer class="c-footer">
    <div>Pos © <?php echo e(date('Y')); ?> || Developed by <strong><a target="_blank" href="#">Sajjad Hossain</a></strong></div>

    <div class="mfs-auto d-md-down-none">Version <strong class="text-danger">1.0</strong></div>
</footer>
<?php /**PATH /home/u803467345/domains/techideasolutions.com/public_html/pos/resources/views/layouts/footer.blade.php ENDPATH**/ ?>