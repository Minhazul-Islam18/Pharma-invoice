<link href="https://unpkg.com/filepond/dist/filepond.css" rel="stylesheet"/>
<link href="https://unpkg.com/filepond-plugin-image-preview/dist/filepond-plugin-image-preview.css" rel="stylesheet">
<?php /**PATH /home/u803467345/domains/techideasolutions.com/public_html/pos/resources/views/includes/filepond-css.blade.php ENDPATH**/ ?>