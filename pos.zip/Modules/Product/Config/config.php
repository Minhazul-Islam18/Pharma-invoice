<?php

return [
    'name' => 'Product'
];
