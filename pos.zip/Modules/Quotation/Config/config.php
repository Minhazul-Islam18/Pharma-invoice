<?php

return [
    'name' => 'Quotation'
];
