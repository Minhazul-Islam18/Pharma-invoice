<?php

return [
    'name' => 'Currency'
];
